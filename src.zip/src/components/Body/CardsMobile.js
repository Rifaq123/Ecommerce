

import * as React from 'react';
import Divider from '@mui/material/Divider';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';

import Apple from "../../assests/images/mobile/apple.png"
import Moto from "../../assests/images/mobile/moto.png"
import Oneplus from "../../assests/images/mobile/oneplus.png"
import Realme from "../../assests/images/mobile/realme.png"
import Samsung from "../../assests/images/mobile/samsung.jpg"
import Vivo from "../../assests/images/mobile/vivo.png"
import Nokia from "../../assests/images/mobile/nokia.png"
import Oppo from "../../assests/images/mobile/oppo.png"
import Mi from "../../assests/images/mobile/mi.png"


import "../../assests/css/style.css"

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Cards() {
  return (
    <div className="CardsMobile">
      <Stack
        direction="row"
        divider={<Divider orientation="vertical" flexItem />}
        spacing={2}
      >
        <div className='cardcircle'><img src={Apple} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Mi} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Moto} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Oneplus} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Realme} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Samsung} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Vivo} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Nokia} className="mobilelogo" alt="" /></div>
        <div className='cardcircle'><img src={Oppo} className="mobilelogo" alt="" /></div>
       
      </Stack>
    </div>
  );
}
