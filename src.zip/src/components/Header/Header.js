
import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";

import SearchIcon from "@mui/icons-material/Search";

import logo from "../../assests/images/flip.png";
import logo1 from "../../assests/images/whitelogo.png";
import { width } from "@mui/system";

import Avatar from "@mui/material/Avatar";
import Badge, { BadgeProps } from '@mui/material/Badge';
import { styled } from '@mui/material/styles';
import IconButton from '@mui/material/IconButton';

import Stack from "@mui/material/Stack";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import LoginIcon from "@mui/icons-material/Login";
// import Stack from '@mui/material/Stack';
import BottomNavigation from "@mui/material/BottomNavigation";
import BottomNavigationAction from "@mui/material/BottomNavigationAction";
import RestoreIcon from "@mui/icons-material/Restore";
import FavoriteIcon from "@mui/icons-material/Favorite";
import LocationOnIcon from "@mui/icons-material/LocationOn";


import "../../assests/css/style.css";


export default function Header() {
  const [value, setValue] = React.useState(0);

  const top100Films = [
    { label: "The Shawshank Redemption", year: 1994 },
    { label: "The Godfather", year: 1972 },
    { label: "The Godfather: Part II", year: 1974 },
    { label: "The Dark Knight", year: 2008 },
    { label: "12 Angry Men", year: 1957 },
    { label: "Schindler's List", year: 1993 },
    { label: "Pulp Fiction", year: 1994 },
  ];

  return (
    <AppBar position="static">
      <Toolbar>
        <Box
          sx={{
            flexGrow: 1,
            width: 1,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box>
            <img src={logo} className="headerimg" alt="" />
            <img src={logo1} className="headerimg1" alt="" />

          </Box>
          

          <Box className="searchparent">
            <SearchIcon className="search" />

            <Autocomplete
              disablePortal
              id="combo-box-demo"
              options={top100Films}
              sx={{ width: 600 }}
              renderInput={(params) => <TextField {...params} label="" />}
              className="input-border"
            />
          </Box>

          <Box>
            <Stack
              direction={{ xs: "column", sm: "row" }}
              spacing={{ xs: 1, sm: 2, md: 4 }}
            >
              <BottomNavigation
                showLabels
                value={value}
                onChange={(event, newValue) => {
                  setValue(newValue);
                }}
              >
                <BottomNavigationAction
                  label="Recents"
                  icon={<RestoreIcon />}
                />
                <BottomNavigationAction
                  label="Favorites"
                  icon={<FavoriteIcon />}
                />
                <BottomNavigationAction
                  label="Location"
                  icon={<LocationOnIcon />}
                />
                <BottomNavigationAction
                  label="Cart"
                  icon={<ShoppingCartIcon />}
                />
                
                <BottomNavigationAction label="Login" icon={<LoginIcon />} />
                <Box
                  sx={{
                    flexGrow: 1,
                    width: 1,
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <Avatar src="/broken-image.jpg" sx={{ m: 1 }} />
                </Box>
              </BottomNavigation>
            </Stack>
            
          </Box>
        </Box>
      </Toolbar>
    </AppBar>
  );
}
