import './App.css';
import Header from "../src/components/Header/Header"
import Category from './components/Body/Category';
import CardsMobile from './components/Body/CardsMobile';

function App() {
  return (
 <>
 <Header/>
 <Category/>
 <CardsMobile/>

 </>
  );
}

export default App;
